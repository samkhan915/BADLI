---
name: Bug report
about: Create a report to help us improve
labels: bug

---

### Actual behaviour
- Tell us what happens

### Expected behaviour
- Tell us what should happen
 
### Steps to reproduce
1. 
2. 
3. 


### Environment data
Android version:

Device model: 

Stock or customized system:

Nextcloud app version:

Nextcloud server version:

### Logs
#### Web server error log
```
Insert your webserver log here
```

#### Nextcloud log (data/nextcloud.log)
```
Insert your Nextcloud log here
```
**NOTE:** Be super sure to remove sensitive data like passwords, note that everybody can look here! You can use the Issue Template application to prefill some of the required information: https://apps.nextcloud.com/apps/issuetemplate
